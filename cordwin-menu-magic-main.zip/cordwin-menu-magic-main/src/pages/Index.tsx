
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, Shield, Zap, Users, Download, ExternalLink, Play, Pause } from "lucide-react";
import { toast } from "@/hooks/use-toast";

const Index = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [rating] = useState(4.8);
  const [userCount] = useState(15420);

  // Particle animation effect
  useEffect(() => {
    const canvas = document.getElementById('particles') as HTMLCanvasElement;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles: Array<{x: number, y: number, vx: number, vy: number, size: number}> = [];
    
    for (let i = 0; i < 50; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 2,
        vy: (Math.random() - 0.5) * 2,
        size: Math.random() * 3 + 1
      });
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = 'rgba(59, 130, 246, 0.1)';
      
      particles.forEach(particle => {
        particle.x += particle.vx;
        particle.y += particle.vy;
        
        if (particle.x < 0 || particle.x > canvas.width) particle.vx *= -1;
        if (particle.y < 0 || particle.y > canvas.height) particle.vy *= -1;
        
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        ctx.fill();
      });
      
      requestAnimationFrame(animate);
    };
    
    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const playSound = (type: 'click' | 'hover') => {
    // Create audio context for sound effects
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    if (type === 'click') {
      oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
      oscillator.frequency.exponentialRampToValueAtTime(400, audioContext.currentTime + 0.1);
    } else {
      oscillator.frequency.setValueAtTime(300, audioContext.currentTime);
    }
    
    gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
    
    oscillator.start();
    oscillator.stop(audioContext.currentTime + 0.1);
  };

  const handlePurchase = () => {
    playSound('click');
    toast({
      title: "Redirecting to Purchase",
      description: "Taking you to our secure payment portal...",
    });
    // Simulate purchase redirect
    setTimeout(() => {
      window.open('https://cordwin.wtf/purchase', '_blank');
    }, 1000);
  };

  const handleDiscord = () => {
    playSound('click');
    toast({
      title: "Joining Discord",
      description: "Opening Discord server invitation...",
    });
    window.open('https://discord.gg/cordwin', '_blank');
  };

  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(
        <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
      );
    }
    
    if (hasHalfStar) {
      stars.push(
        <div key="half" className="relative h-5 w-5">
          <Star className="h-5 w-5 text-gray-300" />
          <Star className="absolute top-0 left-0 h-5 w-5 fill-yellow-400 text-yellow-400" style={{ clipPath: 'inset(0 50% 0 0)' }} />
        </div>
      );
    }
    
    const remainingStars = 5 - Math.ceil(rating);
    for (let i = 0; i < remainingStars; i++) {
      stars.push(
        <Star key={`empty-${i}`} className="h-5 w-5 text-gray-300" />
      );
    }
    
    return stars;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 text-white relative overflow-hidden">
      <canvas id="particles" className="absolute inset-0 pointer-events-none" />
      
      {/* Navigation */}
      <nav className="relative z-10 flex items-center justify-between p-6 backdrop-blur-sm bg-black/20">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-sm">CW</span>
          </div>
          <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            CordWin.WTF
          </span>
        </div>
        
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              setIsPlaying(!isPlaying);
              playSound('click');
            }}
            className="hover:bg-white/10"
          >
            {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            <span className="ml-2">Sound {isPlaying ? 'On' : 'Off'}</span>
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative z-10 text-center py-20 px-6">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-6xl md:text-8xl font-bold mb-6 bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent animate-fade-in">
            CordWin.WTF
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-300 animate-fade-in" style={{ animationDelay: '0.2s' }}>
            The Ultimate Gorilla Tag Mod Menu
          </p>
          
          {/* Rating Display */}
          <div className="flex items-center justify-center space-x-2 mb-8 animate-fade-in" style={{ animationDelay: '0.4s' }}>
            <div className="flex items-center space-x-1">
              {renderStars(rating)}
            </div>
            <span className="text-lg font-semibold">{rating}</span>
            <span className="text-gray-400">({userCount.toLocaleString()} users)</span>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center animate-fade-in" style={{ animationDelay: '0.6s' }}>
            <Button 
              size="lg" 
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-3 text-lg transition-all duration-300 hover:scale-105"
              onClick={handlePurchase}
              onMouseEnter={() => playSound('hover')}
            >
              <Download className="mr-2 h-5 w-5" />
              Buy Now - $19.99
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              className="border-purple-500 text-purple-300 hover:bg-purple-500 hover:text-white px-8 py-3 text-lg transition-all duration-300 hover:scale-105"
              onClick={handleDiscord}
              onMouseEnter={() => playSound('hover')}
            >
              <Users className="mr-2 h-5 w-5" />
              Join Discord
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="relative z-10 py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            Premium Features
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="bg-black/40 border-purple-500/20 backdrop-blur-sm hover:bg-black/60 transition-all duration-300 hover:scale-105 hover:border-purple-500/40 group">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                  <Shield className="h-6 w-6 text-white" />
                </div>
                <CardTitle className="text-white">Undetectable</CardTitle>
                <CardDescription className="text-gray-400">
                  Advanced anti-detection systems keep you safe from bans
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="bg-black/40 border-purple-500/20 backdrop-blur-sm hover:bg-black/60 transition-all duration-300 hover:scale-105 hover:border-purple-500/40 group">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-blue-500 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                  <Zap className="h-6 w-6 text-white" />
                </div>
                <CardTitle className="text-white">50+ Mods</CardTitle>
                <CardDescription className="text-gray-400">
                  Extensive collection of game-changing modifications
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="bg-black/40 border-purple-500/20 backdrop-blur-sm hover:bg-black/60 transition-all duration-300 hover:scale-105 hover:border-purple-500/40 group">
              <CardHeader>
                <div className="w-12 h-12 bg-gradient-to-r from-pink-500 to-red-500 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                  <Users className="h-6 w-6 text-white" />
                </div>
                <CardTitle className="text-white">24/7 Support</CardTitle>
                <CardDescription className="text-gray-400">
                  Premium customer support and regular updates
                </CardDescription>
              </CardHeader>
            </Card>
          </div>

          {/* Detailed Features List */}
          <div className="mt-16 grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-2xl font-bold mb-6 text-blue-400">Movement Mods</h3>
              <ul className="space-y-3 text-gray-300">
                <li className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span>Speed Boost</span>
                </li>
                <li className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span>Fly Mode</span>
                </li>
                <li className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span>No Clip</span>
                </li>
                <li className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span>Super Jump</span>
                </li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-2xl font-bold mb-6 text-purple-400">Visual Mods</h3>
              <ul className="space-y-3 text-gray-300">
                <li className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                  <span>ESP/Wallhacks</span>
                </li>
                <li className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                  <span>Custom Skins</span>
                </li>
                <li className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                  <span>Glow Effects</span>
                </li>
                <li className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                  <span>UI Customization</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="relative z-10 py-20 px-6 bg-black/20 backdrop-blur-sm">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-12 bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
            Get Premium Access
          </h2>
          
          <Card className="bg-gradient-to-br from-purple-600/20 to-blue-600/20 border-purple-500/40 backdrop-blur-sm max-w-md mx-auto">
            <CardHeader>
              <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-black font-bold w-fit mx-auto mb-4">
                MOST POPULAR
              </Badge>
              <CardTitle className="text-3xl text-white">Lifetime Access</CardTitle>
              <CardDescription className="text-xl text-gray-300">
                One-time payment, forever access
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <span className="text-5xl font-bold text-white">$19.99</span>
                <p className="text-gray-400 mt-2">No monthly fees</p>
              </div>
              
              <div className="flex items-center justify-center space-x-1 mb-4">
                {renderStars(rating)}
                <span className="text-sm text-gray-400 ml-2">({userCount.toLocaleString()} satisfied customers)</span>
              </div>
              
              <ul className="space-y-3 text-left">
                <li className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-gray-300">All 50+ premium mods</span>
                </li>
                <li className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-gray-300">Regular updates</span>
                </li>
                <li className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-gray-300">24/7 Discord support</span>
                </li>
                <li className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-gray-300">Anti-detection protection</span>
                </li>
              </ul>
              
              <Button 
                className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white text-lg py-3 transition-all duration-300 hover:scale-105"
                onClick={handlePurchase}
                onMouseEnter={() => playSound('hover')}
              >
                <Download className="mr-2 h-5 w-5" />
                Purchase Now
              </Button>
              
              <p className="text-xs text-gray-500 text-center">
                Secure payment via Stripe • 30-day money-back guarantee
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative z-10 py-20 px-6 text-center">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold mb-6 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            Join the Community
          </h2>
          <p className="text-xl text-gray-300 mb-8">
            Connect with {userCount.toLocaleString()}+ players in our Discord server
          </p>
          <Button 
            size="lg"
            className="bg-[#5865F2] hover:bg-[#4752C4] text-white px-8 py-3 text-lg transition-all duration-300 hover:scale-105"
            onClick={handleDiscord}
            onMouseEnter={() => playSound('hover')}
          >
            <ExternalLink className="mr-2 h-5 w-5" />
            Join Discord Server
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 border-t border-gray-800 py-8 px-6 text-center text-gray-400 bg-black/20 backdrop-blur-sm">
        <p>&copy; 2024 CordWin.WTF - Premium Gorilla Tag Modifications</p>
        <p className="text-sm mt-2">Not affiliated with Another Axiom or Gorilla Tag</p>
      </footer>
    </div>
  );
};

export default Index;
